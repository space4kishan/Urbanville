package jdbc;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/membersDB")
public class membersDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		String socid = request.getParameter("socid");
		String socname = request.getParameter("socname");
		String blockno = request.getParameter("blockno");
		String name = request.getParameter("name");
		String resident_type = request.getParameter("resident_type");
		String no_of_members = request.getParameter("no_of_members");
		String contactno = request.getParameter("contactno");
		String email = request.getParameter("email");
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		PrintWriter out  = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			/* SQL Query*/
			String sql = "insert into project.members(socid,socname,blockno,name,resident_type,no_of_members,contactno,email,username,password)values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, socid);
			ps.setString(2, socname);
			ps.setString(3, blockno);
			ps.setString(4, name);
			ps.setString(5, resident_type);
			ps.setString(6, no_of_members);
			ps.setString(7, contactno);
			ps.setString(8, email);
			ps.setString(9, username);
			ps.setString(10, password);
			ps.executeUpdate();
			//out.print("Submitted");
			//out.println("<html><head></head><body></body><script>alert(\" Society Id : \"+ socid);</script></html>");
	        con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {
			e.printStackTrace();
		}
		out.print("<html><head></head><body></body><script>alert(\"Member "+name+" Added Successfully!! \");</script></html>");
	}

}
