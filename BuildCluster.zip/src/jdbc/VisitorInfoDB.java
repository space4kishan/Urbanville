package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VisitorInfoDB")
public class VisitorInfoDB extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	//System.out.println();  
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   	{
   		
   		//int visitorid;
   		String visitorname = request.getParameter("name");
   		String blockno = request.getParameter("blockno");
   		String purpose = request.getParameter("purpose");
   		String entrytime = dateFormat1.format(date);
   		//String exittime = dateFormat2.format(date);
   		String contactno = request.getParameter("contactno");
   		String noofperson = request.getParameter("noofperson");
   		String username1="";
   		String socid="";
   		String socname="";
   		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			//Statement smt = con.createStatement();
			//getting value of login credentials through cookies
	   		
	   		Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println("login Data(cookie)"+username1);
			
			String qry1 = "select socid,socname from gatekeeper where username=?";
			//String qry3 = "select NOW()";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1,username1);
			ResultSet rs2 = ps1.executeQuery();
			//ResultSet rs3 = smt.executeQuery("select NOW()"); //for date
			while(rs2.next())
			{
				socid = rs2.getString("socid");
				socname = rs2.getString("socname");
			}
			System.out.println(socid);
			System.out.println(socname);
			String qry2 = "insert into visitorinfo(socid,socname,visitorname,blockno,purpose,entrytime,contactno,noofperson)values(?,?,?,?,?,?,?,?)";
			PreparedStatement ps2 = con.prepareStatement(qry2);
			//ps2.setInt(1, visitorid);
			ps2.setString(1, socid);
			ps2.setString(2, socname);
			ps2.setString(3, visitorname);
			ps2.setString(4, blockno);
			ps2.setString(5, purpose);
			ps2.setString(6, entrytime);
			//ps2.setString(7, exittime);
			ps2.setString(7, contactno);
			ps2.setString(8, noofperson);
			
			ps2.executeUpdate();
			
			con.close();
		} 
		catch (ClassNotFoundException e) {e.printStackTrace();} 
		catch (SQLException e) {e.printStackTrace();}
   	}

}
