package jdbc;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/CommitteeEditMyprofile")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2 , maxFileSize = 1024 * 1024 * 10 , maxRequestSize = 1024 * 1024 * 50)
public class CommitteeEditMyprofile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String no_of_blocks = request.getParameter("blocks");
		String amenities = request.getParameter("amenities");
		String contactno = request.getParameter("contactno");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		Part part = request.getPart("photo");
		String filename = extractFileName(part);
		System.out.print(filename);
		String savepath = "C:\\Users\\DELL\\New-eclipse-workspace\\SocietyManagementSystem\\WebContent\\images\\" + File.separator + filename;
		File fileSaveDir = new File(savepath);
		part.write(savepath + File.separator);
		
		PrintWriter out = response.getWriter();
		try
		{	
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			//getting credential value of committee through cookies
			String username1="";
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println(username1);
			
			/* SQL Query*/
			String sql = "UPDATE project.societylist SET name=?,address=?,blocks=?,amenities=?,contactno=?,email=?,password=?,photo=?,photopath=? where socid=?";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, name);
			ps.setString(2, address);
			ps.setString(3, no_of_blocks);
			ps.setString(4, amenities);
			ps.setString(5, contactno);
			ps.setString(6, email);
			ps.setString(7, password);
			ps.setString(8, filename);
			ps.setString(9, savepath);
			ps.setString(10, username1);
			ps.executeUpdate();
	        con.close();
	        
		}
		catch(ClassNotFoundException e) {}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("work_comm_MyProfile.jsp");
	       rd.forward(request,response);
	       out.print("<html><head></head><body></body><script>alert(\" Data Updated Successfully! \");</script></html>");
		
	}
	private String  extractFileName(Part part)
	{
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for(String s : items)
		{
			if (s.trim().startsWith("filename"))
			{
				return s.substring(s.indexOf("=") + 2, s.length()-1 );
			}
		}
		return "";
	}

}
