package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/maintenanceDB")
public class maintenanceDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String blockno = request.getParameter("blockno");
		String date = request.getParameter("date");
		String electricitybill = request.getParameter("electricitybill");
		String waterbill = request.getParameter("waterbill");
		String liftmaintenance = request.getParameter("liftmaintenance");
		String security = request.getParameter("security");
		PrintWriter out = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			String socid="";
			String username1="";
			String socname="";
			String name="";
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println(username1);
			
			String qry1 = "select socid,socname,name from project.members where socid=? AND blockno=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1,username1);
			ps1.setString(2, blockno);
			ResultSet rs2 = ps1.executeQuery();
			while(rs2.next())
			{
				socid = rs2.getString("socid");
				socname = rs2.getString("socname");
				name = rs2.getString("name");
			}
			System.out.println(socid);
			System.out.println(socname);
			System.out.println(name);
			String sql = "insert into project.maintenance(socid,socname,blockno,name,date,electricitybill,waterbill,liftmaintenance,security)values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, socid);
			ps.setString(2, socname);
			ps.setString(3, blockno);
			ps.setString(4, name);
			ps.setString(5, date);
			ps.setString(6, electricitybill);
			ps.setString(7, waterbill);
			ps.setString(8, liftmaintenance);
			ps.setString(9, security);
			ps.executeUpdate();
			
	        con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
		out.print("<html><h1>Maintenance Distributed!</h1></html>");
	}
}
