package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.mysql.jdbc.ResultSet;


@WebServlet("/complaintDB")
public class complaintDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();  
		
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		String blockno = request.getParameter("blockno");
		String name = request.getParameter("name");
		//PrintWriter out  = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			String username1="";
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println(username1);
			String socid="";
			String socname="";
			
			String qry1 = "select socname,socid from project.members where username=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1,username1);
			
			ResultSet rs2 = ps1.executeQuery();
			
			while(rs2.next())
			{
				socid = rs2.getString("socid");
				socname = rs2.getString("socname");
			}
			System.out.println(socid);
			System.out.println(socname);
			String qry2 = "insert into project.complaint(blockno,socid,socname,name,subject,content)values(?,?,?,?,?,?)";
			PreparedStatement ps2 = con.prepareStatement(qry2);
			ps2.setString(1, blockno);
			ps2.setString(2, socid);
			ps2.setString(3, socname);
			ps2.setString(4, name);
			ps2.setString(5, subject);
			ps2.setString(6, content);
			ps2.executeUpdate();
	        con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
		
		out.print("<html><head></head><body></body><script>alert(\" Complaint Submitted!! \");</script></html>");
		response.sendRedirect("work_mem_Complaint.jsp"); 
	}

}
