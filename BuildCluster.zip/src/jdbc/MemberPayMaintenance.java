package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/MemberPayMaintenance")
public class MemberPayMaintenance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String payment = "";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			//String socid="";
			int maintenanceid = Integer.parseInt(request.getParameter("maintenanceid"));
			//System.out.println("blockno From Servlet : "+blockno);
			/*Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				socid = ck[i].getValue();//printing name and value of cookie  
			}
			System.out.println("socid from Servlet(MemberPayMaintenance.java): "+socid);*/
			String qry1 = "select payment from project.maintenance where maintenanceid=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setInt(1, maintenanceid);
			
			ResultSet rs1 = ps1.executeQuery();
			while(rs1.next())
			{
				payment = rs1.getString("payment");
			}
			System.out.println("Payment Status : "+payment);
			
			if(payment.equals("paid"))
			{				
				out.print("<html><center><h1 style=\"margin:100px 0px 0px 0px;color:red;\">Maintenance is already paid!!</h1></center></html>");
			}
			else
			{
				String qry2 = "update project.maintenance set payment='paid' where maintenanceid=?";
				
				PreparedStatement ps2 = con.prepareStatement(qry2);
				ps2.setInt(1, maintenanceid);
				ps2.executeUpdate();
				con.close();
				
				RequestDispatcher rd=request.getRequestDispatcher("work_mem_Maintenance.jsp");
				rd.forward(request,response);
			}
			
		 } 
		 catch (ClassNotFoundException e) {e.printStackTrace();} 
		 catch (SQLException e) {e.printStackTrace();}
		
	}

}
