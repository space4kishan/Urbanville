package jdbc;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/comm_noticeDB")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2 , maxFileSize = 1024 * 1024 * 10 , maxRequestSize = 1024 * 1024 * 50)
public class comm_noticeDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter(); 
		
		String blockno ="";
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		String socid="";
		String socname="";
		Part part = request.getPart("attachment");
		String filename = extractFileName(part);
		System.out.print(filename);
		String savepath = "C:\\Users\\DELL\\New-eclipse-workspace\\SocietyManagementSystem\\WebContent\\images\\" + File.separator + filename;
		File fileSaveDir = new File(savepath);
		part.write(savepath + File.separator);
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				socid = ck[i].getValue();		//value of cookie  
			}
			System.out.println(socid);
			
			String qry1 = "select socname from project.members where socid=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1, socid);
			
			ResultSet rs2 = ps1.executeQuery();
			while(rs2.next())
			{
				socname = rs2.getString("socname");
			}
			System.out.println(socname);
			System.out.println("Society ID : "+socid);
			String query = "insert into project.notice(socid,blockno,socname,subject,content,photo,photopath)values(?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, socid);
			ps.setString(2, blockno);
			ps.setString(3, socname);
			ps.setString(4, subject);
			ps.setString(5, content);
			ps.setString(6, filename);
			ps.setString(7, savepath);
			ps.executeUpdate();
			con.close();
		} 
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
		
		System.out.println("Notice Uploaded");
		response.sendRedirect("./work_comm_Notice.jsp");
	}
	private String  extractFileName(Part part)
	{
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for(String s : items)
		{
			if (s.trim().startsWith("filename"))
			{
				return s.substring(s.indexOf("=") + 2, s.length()-1 );
			}
		}
		return "";
	}
	

}
