package jdbc;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;



@WebServlet("/photoTest")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2 , maxFileSize = 1024 * 1024 * 10 , maxRequestSize = 1024 * 1024 * 50)
public class photoTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		// doGet(request, response);
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		Part part = request.getPart("photo");
		String filename = extractFileName(part);
		System.out.print(filename);
		String savepath = "C:\\Users\\DELL\\New-eclipse-workspace\\SocietyManagementSystem\\WebContent\\images\\" + File.separator + filename;
		File fileSaveDir = new File(savepath);
		part.write(savepath + File.separator);
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testing1?characterEncoding=latin1","root","kido1999");
			String qry1 = "insert into testing1.phototest(id,photo,filename)values(?,?,?);";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1 , id);
			ps1.setString(2, savepath);
			ps1.setString(3, filename);
			ps1.executeUpdate();
			con.close();
			out.print("Thai gyu bapu!!!");
			
		}
		catch(Exception e) { e.printStackTrace();}
	}
	
	private String  extractFileName(Part part)
	{
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for(String s : items)
		{
			if (s.trim().startsWith("filename"))
			{
				return s.substring(s.indexOf("=") + 2, s.length()-1 );
			}
		}
		return "";
	}

}
