package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/facilityDB")
public class facilityDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//int slotid = 1;
		String blockno = request.getParameter("blockno");
		String name = request.getParameter("name");
		String purpose = request.getParameter("purpose");
		String amenities = request.getParameter("amenities");
		String fromdate = request.getParameter("fromdate");
		String todate = request.getParameter("todate");
		String amountofpeople = request.getParameter("quantity");
		PrintWriter out = response.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			String socid="",username1="",socname="",fromdateStored="",todateStored="";
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println(username1);
			
			String qry1 = "select * from project.members where username=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1,username1);
			ResultSet rs2 = ps1.executeQuery();
			while(rs2.next())
			{
				socid = rs2.getString("socid");
				socname = rs2.getString("socname");
				blockno = rs2.getString("blockno");
			}
			System.out.println(socid);
			
			String query2 = "select * from project.facilityslot where socid=? or blockno=?";
			PreparedStatement ps2 = con.prepareStatement(query2);
			ps2.setString(1, socid);
			ps2.setString(2, blockno);
			ResultSet rs3 = ps2.executeQuery();

			while(rs3.next())
			{
				fromdateStored = rs3.getString("fromdate");   	//fetching the stored date for comparison
				todateStored = rs3.getString("todate");
			}
			System.out.println("fromdate from work_mem_facilityslot.jsp : "+fromdateStored);
			System.out.println("todate from work_mem_facilityslot.jsp : "+todateStored);
			if(fromdate.equals(fromdateStored))
			{
				out.print("<html><head></head><body></body><script>alert(\"Oops!The Place is already Occupied at that Day. \");</script></html>");
				RequestDispatcher rd=request.getRequestDispatcher("work_mem_FacilityReserve.jsp");
				rd.forward(request,response);
			}
			else
			{
				String sql = "insert into project.facilityslot(socid,socname,blockno,name,purpose,amenities,fromdate,todate,amountofpeople)values(?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, socid);
				ps.setString(2, socname);
				ps.setString(3, blockno);
				ps.setString(4, name);
				ps.setString(5, purpose);
				ps.setString(6, amenities);
				ps.setString(7, fromdate);
				ps.setString(8, todate);
				ps.setString(9, amountofpeople);
				ps.executeUpdate();
				
		        con.close();
			}
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
		
		out.print("<html><head></head><body></body><script>alert(\" Amenity Reserved Successfully!! \");</script></html>");
		//response.sendRedirect("work_mem_Complaint.jsp"); 
	}

}
