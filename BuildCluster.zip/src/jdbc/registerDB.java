package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registerDB")
public class registerDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		
		response.setContentType("text/html");
		//int regID = 1;
		String socname = request.getParameter("socname");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String blocks = request.getParameter("blocks");
		String type = request.getParameter("type");
		String amenities = request.getParameter("amenities");
		String contactno = request.getParameter("contactno");
		String email = request.getParameter("email");
		PrintWriter out  = response.getWriter();
		try 
		{

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
		
			/* SQL Query*/
			String sql = "insert into register(socname,name,address,blocks,type,amenities,contactno,email)values(?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			//ps.setInt(1, regID);
			ps.setString(1, socname);
			ps.setString(2, name);
			ps.setString(3, address);
			ps.setString(4, blocks);
			ps.setString(5, type);
			ps.setString(6, amenities);
			ps.setString(7, contactno);
			ps.setString(8, email);
			ps.executeUpdate();
			out.println("<html><head></head><body></body><script>alert(\" Society Id : \"+ socid);</script></html>");
	        con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {
			e.printStackTrace();
		}
        
	}

}
