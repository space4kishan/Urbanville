package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GatekeeperRegisterDB")
public class GatekeeperRegisterDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		//int gatekeeperid = 1;
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String dateofbirth = request.getParameter("dateofbirth");
		String contactno = request.getParameter("contactno");
		String joiningdate = request.getParameter("joiningdate");
		String username = "";
		String password = "";
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			String username1="";
			Cookie ck[]=request.getCookies();  
			for(int i=0;i<ck.length;i++)
			{  
				username1 = ck[i].getValue();		// value of cookie  
			}
			System.out.println(username1);
			String socid="";
			String socname="";
			
			String qry1 = "select socname,socid from project.societylist where socid=?";
			PreparedStatement ps1 = con.prepareStatement(qry1);
			ps1.setString(1,username1);
			
			ResultSet rs2 = ps1.executeQuery();
			
			while(rs2.next())
			{
				socid = rs2.getString("socid");
				socname = rs2.getString("socname");
			}
			System.out.println(socid);
			System.out.println(socname);
			username = password = socid + name;
			System.out.println(username +" &"+ password);
			String qry2 = "insert into project.gatekeeper(socid,socname,name,gender,dateofbirth,contactno,joiningdate,username,password)values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps2 = con.prepareStatement(qry2);
			//ps2.setInt(1, gatekeeperid);
			ps2.setString(1, socid);
			ps2.setString(2, socname);
			ps2.setString(3, name);
			ps2.setString(4, gender);
			ps2.setString(5, dateofbirth);
			ps2.setString(6, contactno);
			ps2.setString(7, joiningdate);
			ps2.setString(8, username);
			ps2.setString(9, password);
			ps2.executeUpdate();
	        con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
	}

}
