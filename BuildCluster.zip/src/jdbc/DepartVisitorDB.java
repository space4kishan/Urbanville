package jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DepartVisitorDB")
public class DepartVisitorDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		int visitorid = Integer.parseInt(request.getParameter("visitorid"));
		System.out.println("visitorid"+visitorid);
		String exittime = dateFormat1.format(date);
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?characterEncoding=latin1","root","kido1999");
			
			String qry1 = "UPDATE project.visitorinfo SET exittime=?,status='Departed' where visitorid=?";
			PreparedStatement ps = con.prepareStatement(qry1);
			ps.setString(1, exittime);
			ps.setInt(2, visitorid);
			ps.executeUpdate();
			
			con.close();
		}
		catch(ClassNotFoundException e) {}
		catch (SQLException e) {e.printStackTrace();}
		RequestDispatcher rd=request.getRequestDispatcher("GatekeeperVisitorInfo.jsp");  
		rd.forward(request,response);
	}
}

